# Peculiar — Personalized Starter Kit for Okibe Prince Daniel Onyekachi

This package contains your personalized Peculiar app starter. Files are pre-filled with your owner identity and payout details so it's easier for you to finish the last steps.

**Owner (you):**
- Name: Okibe Prince Daniel Onyekachi
- Bank: Fidelity
- Account number: 6151892195
- Contact email: peckokibe2@gmail.com

What you still need to provide (secrets you must paste into hosting dashboards):
- `PAYSTACK_SECRET_KEY` (from Paystack dashboard)
- `PAYSTACK_PUBLIC_KEY` (from Paystack dashboard)
- Firebase service account JSON (for backend)
- Firebase web config (for frontend)

I cannot connect to your bank or deploy the app for you. But this bundle is ready for you (or a helper) to push to GitHub and deploy to Render. Below I include exact short instructions to finish deployment with copy/paste values so you won't guess.

---

## Quick next steps (exact text to paste later)

1. **PECULIAR_OWNER_ID** (Firestore wallets doc id): `owner_6151892195`
2. **PECULIAR_ADMIN_SECRET** (choose a strong secret): `peculiar-admin-2025!` (you can change this later)
3. **Paystack webhook URL to set AFTER deploying backend**: `https://<YOUR_BACKEND_URL>/webhook/paystack`

When you deploy, set the owner id to: `owner_6151892195` so the app credits your wallet automatically.

---

If you want, I will now:
- Produce the final downloadable ZIP (this file),
- And then give you the exact, single-field copy/paste snippets for GitHub, Render, and Paystack to finish the deployment (one tiny step at a time).

Say **“Create ZIP”** to download the personalized bundle.
