import React from 'react';

export default function App(){
  return (
    <div style={{maxWidth:900,margin:'24px auto',padding:16}}>
      <header style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
        <h1 style={{margin:0}}>Peculiar</h1>
        <small style={{color:'#666'}}>Built with ChatGPT — Personalized for Okibe Prince Daniel Onyekachi</small>
      </header>

      <section style={{marginTop:16,background:'#fff',padding:16,borderRadius:8}}>
        <h3>Welcome, Okibe 👋</h3>
        <p>This is your Peculiar platform. All tips/payments go to the owner account below.</p>
        <ul>
          <li><strong>Owner name:</strong> Okibe Prince Daniel Onyekachi</li>
          <li><strong>Bank:</strong> Fidelity</li>
          <li><strong>Account number:</strong> 6151892195</li>
          <li><strong>Contact email:</strong> peckokibe2@gmail.com</li>
        </ul>
        <p>To finish going live you must provide Paystack keys and Firebase credentials. I will guide you with exact copy/paste text.</p>
      </section>

      <footer style={{marginTop:24,textAlign:'center',color:'#888'}}>
        <small>Peculiar — Copyright © Onyekachi. Built with ChatGPT.</small>
      </footer>
    </div>
  );
}
